pxkcd(1/sqrt(2*pi)+c(-0.01,0,0.01),1,F,T)
pxkcd(1/sqrt(2*pi)+c(-0.01,0,0.01),1,F,F)
pxkcd(1/sqrt(2*pi)+c(-0.01,0,0.01),1,T,F)
pxkcd(1/sqrt(2*pi)+c(-0.01,0,0.01),1,T,T)


pxkcd(10^c(-11,-9,-7),c(1,2),F,T)
pxkcd(10^c(-11,-9,-7),c(1,2),F,F)
pxkcd(10^c(-11,-9,-7),c(1,2),T,F)
pxkcd(10^c(-11,-9,-7),c(1,2),T,T)
