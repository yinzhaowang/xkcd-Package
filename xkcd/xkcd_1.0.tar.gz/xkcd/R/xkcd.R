rxkcd=function(n, sd=1){
    x=rnorm(n,0,sd)
    f_x=dnorm(x,0,sd)
    y=runif(n,0,f_x)
    return(y)
}

dxkcd=function(x, sd = 1, log = FALSE,swap.end.points = FALSE){
    #if check
    if ( sum(is.na(x))+sum(is.na(sd))>0 ){
        stop("Some values of x or sd are NA.")
    }
    if ( sum(is.infinite(sd))>0 ){
        stop("Some values of sd are infinite.")
    }
    if ( sum(sd<=0)>0 ){
        stop("Some values of sd are non-positive.")
    }
    n=max(length(x), length(sd))
    x=rep(x, length.out = n  ) 
    sd=rep(sd, length.out = n  ) 
    #
    #
    sqrt2pisd=sqrt(2*pi)*sd
    up_domian=1/sqrt2pisd
    log2=log(2)
    log2sd2=log(2*sd^2)
    logPi=log(pi)
    log2Pisd2=log2sd2+logPi
    y=numeric(n)
    #initial evaluation
    index_x_0= (x==0)
    if (sum(index_x_0)>0 ){
        if (log == FALSE & swap.end.points == FALSE){y[index_x_0]=Inf}
        else if (log == FALSE & swap.end.points == TRUE){y[index_x_0]=0}
        else if (log == TRUE & swap.end.points == FALSE){y[index_x_0]=Inf}
        else if (log == TRUE & swap.end.points == TRUE){y[index_x_0]=-Inf}
    }
    index_x_max= (x==up_domian)
    if (sum(index_x_max)>0 ){
        if (log == FALSE & swap.end.points == FALSE){y[index_x_max]=0}
        else if (log == FALSE & swap.end.points == TRUE){y[index_x_max]=Inf}
        else if (log == TRUE & swap.end.points == FALSE){y[index_x_max]=-Inf}
        else if (log == TRUE & swap.end.points == TRUE){y[index_x_max]=-Inf}
    }  
    #swap end points new
    ### The following is not needed, since initial value of y is 0.
    #  index_0=x<0 | x>up_domian
    #  y[index_0]=0
    
    #non-trivial evaluation
    index_non01= (x>0) & (x<up_domian)
    if (sum(index_non01)>0){
        if (log == FALSE & swap.end.points == FALSE){
            y[index_non01]=2*sqrt((-1/2*log2Pisd2[index_non01]-log(x[index_non01]))*2*sd[index_non01]^2)
        }
        else if(log == FALSE & swap.end.points == TRUE){
            y[index_non01]=2*sqrt( -2*sd[index_non01]^2*log1p(-sqrt2pisd[index_non01]*x[index_non01])  )
        }
        else if(log == TRUE & swap.end.points == FALSE){
            y[index_non01]=log2+1/2*( log(-1/2*log2sd2[index_non01]-1/2*logPi-log(x[index_non01]))  +log2sd2[index_non01])
        }
        else if(log == TRUE & swap.end.points == TRUE){
            y[index_non01]=log2+1/2*(log( -log1p(-sqrt2pisd[index_non01]*x[index_non01]))+log2sd2[index_non01] )
        }
    }  
    return(y)
}



pxkcd=function(q, sd = 1, log.p = FALSE,swap.end.points = FALSE){
    if ( sum(is.na(q))+sum(is.na(sd))>0 ){
        stop("Some values of q or sd are NA.")
    }
    if ( sum(is.infinite(sd))>0 ){
        stop("Some values of sd are infinite.")
    }
    if ( sum(sd<=0)>0 ){
        stop("Some values of sd are non-positive.")
    }
    n=max(length(q), length(sd))
    q=rep(q, length.out = n  ) 
    sd=rep(sd, length.out = n  ) 
    p=numeric( length(q))
    log2=log(2)
    sqrt2pisd=sqrt(2*pi)*sd
    up_domian=1/sqrt2pisd
    #initial evaluation
    index_q_0= (q<=0)
    if (sum(index_q_0)>0 ){
        if (log.p == FALSE  ){p[index_q_0]=0}
        else if (log.p == TRUE){p[index_q_0]=-Inf }
    }
    index_q_max= (q>=up_domian)
    if (sum(index_q_max)>0 ){
        if (log.p == FALSE  ){p[index_q_max]=1}
        else if (log.p == TRUE){p[index_q_max]=0 }
    }  
    #non-trivial evaluation: constant set up
    index_non0= (q>0) & (q<up_domian)
    index_q2= (q>0)&(q<2^{-30})
    index_q3=(q>=2^{-30})&(q< up_domian)
    if (sum(index_non0)>0){
        if (swap.end.points == FALSE){
            h1=dxkcd(q[index_non0],sd=sd[index_non0])/2
            fp1=pnorm(-h1 ,mean=0,sd=sd[index_non0])
        }
        else if(sum(index_q3)>0 )
        {
            h=dxkcd(q[index_q3],sd=sd[index_q3],swap.end.points = TRUE)/2
            fp=pnorm(-h ,mean=0,sd=sd[index_q3])
        }
        ###extra
        #  if(sum(index_q2)>0){
        #    if(log.p==FALSE){
        #      c=sqrt(2*sd^3 *sqrt(2*pi) )*4/3
        #      p[index_q2]=c*q[index_q2]^{3/2}
        #    }
        #    else{
        #      logc=log(sqrt(2*sd^3 *sqrt(2*pi) )*4/3)
        #      p[index_q2]=logc+3/2*log(q[index_q2])  
        #    }
        #non-trivial evaluation  
        #case1
        if (log.p == FALSE & swap.end.points == FALSE){
            p[index_non0]=2*fp1+q[index_non0]*(2)*h1
        }
        #case2
        else if(log.p == FALSE & swap.end.points == TRUE){
            if(sum(index_q2)>0){
                c=sqrt(2*sd[index_q2]^3 *sqrt(2*pi) )*4/3
                p[index_q2]=c*q[index_q2]^{3/2}
            }
            if(sum(index_q3)>0){
                p[index_q3]=1-2*(fp+(up_domian[index_q3]-q[index_q3])*h)
            }
        }
        #case3
        else if(log.p == TRUE & swap.end.points == FALSE){
            index_q4= (q>0)&(q<2^{-1000})
            index_q5=(q>=2^{-1000})&(q< up_domian)
            #    p[index_non0]=log2+pnorm(-h1 ,mean=0,sd=sd,log.p =TRUE)+log1p(q[index_non0]*h1 /fp1)
            if(sum(index_q4)>0){
                xx=log(sqrt(2* pi)*sd[index_q4] *q[index_q4] )
                p[index_q4]=log(2/sqrt(pi))+xx+
                    log(1/2-xx)-1/2*log(-xx)
            }
            if(sum(index_q5)>0){
                h2=dxkcd(q[index_q5],sd=sd[index_q5])/2
                fp2=pnorm(-h2 ,mean=0,sd=sd[index_q5])
                t=2*(fp2+q[index_q5]*h2)
                p[index_q5]=log(t)
            }      
        }
        #case4
        else if(log.p == TRUE & swap.end.points == TRUE){
            if(sum(index_q2)>0){
                logc=log(sqrt(2*sd[index_q2]^3 *sqrt(2*pi) )*4/3)
                p[index_q2]=logc+3/2*log(q[index_q2])  
            }
            if(sum(index_q3)>0){
                t=1-2*(fp+(up_domian[index_q3]-q[index_q3])*h)
                p[index_q3]=log(t)
            }
        }
    }   
    return(p)
}





qxkcd=function(p, sd = 1, log.p = FALSE,swap.end.points = FALSE){
    if ( sum(is.na(p))+sum(is.na(sd))>0 ){
        stop("Some values of q or sd are NA.")
    }
    if ( sum(is.infinite(p))+sum(is.infinite(sd))>0 ){
        stop("Some values of q or sd are infinite.")
    }
    if ( sum(sd<=0)>0 ){
        stop("Some values of sd are non-positive.")
    }
    n=max(length(p), length(sd))
    p=rep(p, length.out = n ) 
    sd=rep(sd, length.out = n ) 
    sqrt2pisd=sqrt(2*pi)*sd
    up_domian=1/sqrt2pisd
    q=numeric(n)
    if (sum(p>1)+sum(p<0)>0 &log.p==FALSE){
        stop("Some values of p are invalid.")
    }
    if(sum(p>0)>0 & log.p==TRUE){
        stop("Some values of p are invalid.")
    }
    else{
        for(i in 1:n){
            fun=function(q){return(pxkcd(q, sd = sd[i], log.p = log.p,swap.end.points = swap.end.points)-p[i])}
            q[i]=uniroot(fun,lower=0,upper=up_domian[i])$root
        }
        return(q)
    }
}


